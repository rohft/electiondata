export type FieldType = "single-select" | "multi-select" | "photo" | "notes";

export interface FieldOption {
  id: string;
  label: string;
}

export interface CategoryField {
  id: string;
  type: FieldType;
  label: string;
  options?: FieldOption[]; // for select types
}

export interface CategoryDataEntry {
  fieldId: string;
  value: string | string[] | null; // string for notes/single-select/photo, string[] for multi-select
}

export interface CategoryDataMap {
  [categoryId: string]: {
    fields: CategoryField[];
    data: CategoryDataEntry[];
  };
}
